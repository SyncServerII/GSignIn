//
//  GSignIn.h
//  GSignIn
//
//  Created by Christopher G Prince on 12/18/20.
//

#import <Foundation/Foundation.h>

//! Project version number for GSignIn.
FOUNDATION_EXPORT double GSignInVersionNumber;

//! Project version string for GSignIn.
FOUNDATION_EXPORT const unsigned char GSignInVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GSignIn/PublicHeader.h>

#import <GSignIn/GoogleSignInAll.h>
